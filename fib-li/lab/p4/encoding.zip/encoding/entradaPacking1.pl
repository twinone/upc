% Width and height of the large piece of cloth
width(3).
height(5).

% rect(pieceNum,pieceWidth,pieceHeight)
rect(1,2,2).
rect(2,2,2).
rect(3,1,4).
rect(4,3,1).

%% Possible solution:
%% 3  1  1 
%% 3  1  1 
%% 3  2  2 
%% 3  2  2 
%% 4  4  4 
