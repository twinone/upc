width(5).
height(7).

rect(1,3,1).
rect(2,1,2).
rect(3,2,2).
rect(4,1,5).
rect(5,3,3).
rect(6,1,3).
rect(7,2,1).
rect(8,1,6).
rect(9,1,1).

%% Possible solution:
%% 4  9  1  1  1 
%% 4  8  6  3  3 
%% 4  8  6  3  3 
%% 4  8  6  7  7 
%% 4  8  5  5  5 
%% 2  8  5  5  5 
%% 2  8  5  5  5 
